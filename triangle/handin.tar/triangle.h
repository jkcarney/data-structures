/*  Name: Joshua Carney
    Course: 362-2
    Description: A triangle header class"
*/
#ifndef triangle_H
#define triangle_H

class triangle {

    private:
        float m_side1;
        float m_side2;
        float m_side3;
    
    public:
        triangle() {
            m_side1 = 1;
            m_side2 = 1;
            m_side3 = 1;
        }

        triangle(float x) {
            m_side1 = x;
            m_side2 = x;
            m_side3 = x;
        }

        triangle(float x, float y, float z) {
            m_side1 = x;
            m_side2 = y;
            m_side3 = z;
        }

        float get_side1() const {
            return m_side1;
        }

        float get_side2() const {
            return m_side2;
        }

        float get_side3() const {
            return m_side3;
        }

        float perimeter() {
            return m_side1 + m_side2 + m_side3;
        }

        float largest_side() const {
            if(m_side1 > m_side2 && m_side1 > m_side3){
                return m_side1;
            } else if(m_side2 > m_side1 && m_side2 > m_side3){
                return m_side2;
            } else {
                return m_side3;
            }
        }

        bool is_right() {
            return  (m_side1 * m_side1) + (m_side2 * m_side2) == (m_side3 * m_side3) ||
                    (m_side2 * m_side2) + (m_side3 * m_side3) == (m_side1 * m_side1) ||
                    (m_side1 * m_side1) + (m_side3 * m_side3) == (m_side2 * m_side2);
        }
};

#endif